<?php
/**
 * Translate language string stored in database. Ex: Custom Fields
 *
 * @since 1.4.2
 * @package GeoDirectory
 */

// Language keys
?>